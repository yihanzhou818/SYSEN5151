"""Generated from contracts/api-v1.yaml; do not edit by hand."""
from typing import Protocol

CONTRACT_SHA256 = '57b4931b5a312fca03129204eef39e39e67c19e6a149b9f887e65bf6d7935279'

class InternalServer(Protocol):
    def acquire_evidence(self, request: dict) -> dict: ...
    def calculate_ranking(self, request: dict) -> dict: ...
    def check_explanation(self, request: dict) -> dict: ...
    def present_comparison(self, request: dict) -> dict: ...

class InternalClient:
    def __init__(self, server, validate):
        self.server = server
        self.validate = validate

    def acquire_evidence(self, request: dict) -> dict:
        self.validate('ValidatedRequest', request)
        result = self.server.acquire_evidence(request)
        self.validate('DatedEvidence', result)
        return result

    def calculate_ranking(self, request: dict) -> dict:
        self.validate('DatedEvidence', request)
        result = self.server.calculate_ranking(request)
        self.validate('ComputedRecord', result)
        return result

    def check_explanation(self, request: dict) -> dict:
        self.validate('ComputedRecord', request)
        result = self.server.check_explanation(request)
        self.validate('CheckedExplanation', result)
        return result

    def present_comparison(self, request: dict) -> dict:
        self.validate('PresentationRequest', request)
        result = self.server.present_comparison(request)
        self.validate('ComparisonView', result)
        return result
