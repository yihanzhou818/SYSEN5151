# ADR-0004 — Preserve F.0 facade, implement F.1–F.5 behind model-derived contract v1

Status: implemented in the controlled Chapter 6–7 product copy; owner review pending.

Context: native F.0 264782 now decomposes into F.1–F.5 269034–269038, with IF.01–IF.04 269039–269042. Earlier code implemented calculation and presentation inside one F.0 function, and ResearchRuntime calculated twice around AI coordination. That concealed the IF.03 fan-out and did not expose the first-level boundaries.

Decision: start from docs/internal-flow-list.md; write OpenAPI 3.1 contracts/api-v1.yaml before the new implementation; generate server signatures and a validating client from that file. Implement each function in FunctionalServer and route ResearchRuntime through the client once per function. Preserve the old F.0 public facade and all independent-oracle tests. Configuration is injected as an immutable control snapshot; its version is carried in messages to detect mismatches. IF.03 is deep-copied to F.4 and F.5, so explanation processing cannot change the displayed numerical record. IF.04's identity must match IF.03 before presentation.

Units/types/errors are explicit in the contract. Provider calendar commentary stays in raw fixture evidence, while IF.02 projects only fields authorized by the new schema. Existing retry, missing-news and unavailable-AI semantics are retained; no vendor schema is approved by this local OpenAPI document. A single local jsonschema dependency is justified by validation of every internal request and response.

Scope corrections: framework Swagger/ReDoc/OpenAPI endpoints were unrequested entry points and are disabled. The inherited historical sandbox's sentiment weighting, 2–5-stock normalization and future-return interaction were outside UC.1 and are removed from this delivered product copy. Previous commits retain their history.

Model entities affected: F.0 264782; F.1–F.5 269034–269038; IF.01–IF.04 269039–269042; IO.10 264838; system requirement 1.4.1 264940 and the sixteen requirements allocated across F.1–F.5. No physical-subsystem mechanism allocation is introduced before the corresponding architecture lesson.

Validation: see evidence/ch6-ch7/unit-tests.txt, http-results.json and browser verification screenshot. These establish local controlled conformance, not live-service suitability or human acceptance.
