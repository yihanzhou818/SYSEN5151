# Model-authorized internal flows

Source: Innoslate 659, F.0 264782; saved model revision 2026-10-22. This list preceded the machine-readable contract and code refactor.

- IF.01 Validated Comparison Request: F.1 -> F.2; schema ValidatedRequest.
- IF.02 Validated Dated Evidence: F.2 -> F.3; schema DatedEvidence.
- IF.03 Computed Scores Drivers and Evidence: F.3 -> ['F.4', 'F.5']; schema ComputedRecord.
- IF.04 Checked Explanation and Availability: F.4 -> F.5; schema CheckedExplanation.

IO.10 is a versioned control, not an invented payload field or physical mechanism allocation. The contract preserves this separation.
