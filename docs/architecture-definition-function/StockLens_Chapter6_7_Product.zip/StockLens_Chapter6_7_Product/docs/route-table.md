# Chapter 6 entry-point and use-case audit

Audited 2026-10-22. Source product baseline: StockLen Chapter 4–5 controlled implementation; current model: project 659, UC.1 185145, MF.0 264781, F.0 264782. This is an AI-assisted technical mapping prepared for owner review, not evidence that six students independently performed it.

## HTTP inventory and disposition

| Entry point | Handler | Model/use-case trace | Disposition |
|---|---|---|---|
| GET / | dashboard | UC.1.1/1.2; legacy fixture selection | Retained, explicitly fictional fixed DEMO_A/DEMO_B; not scored production comparison. |
| POST /compare | compare | UC.1 legacy nominal path | Retained compatibility demonstration; fixture never relabelled with submitted real symbols. |
| GET /research | research_dashboard | UC.1.1/1.2; F.1/F.5 | Current controlled research UI. |
| POST /research/compare | research_compare | UC.1.1–1.8; F.1–F.5, IF.01–IF.04 | Current synthetic calculation, grounding checks and display. |
| GET /research/status | research_status | UC.1 control/status context, trace 0/9; EF.5 264793 | Current maintainer/support boundary; does not create an extra business use case. |
| POST /research/configuration | research_configuration | UC.1 maintained precondition; IO.10; EF.5 264793 | Retained local controlled API; atomic configuration change. Not production authorization. |
| GET /research/evidence/{source_id} | research_evidence | UC.1.8; included source inspection UC.1.C; IO.02 | Read-only inspection of a source actually returned in the synthetic comparison; unknown ID 404. |
| GET /docs | framework-generated Swagger UI | No modeled user task | Removed by docs_url=None. |
| GET /redoc | framework-generated ReDoc UI | No modeled user task | Removed by redoc_url=None. |
| GET /openapi.json | framework-generated public schema | No modeled user task | Removed by openapi_url=None; internal contract stays in contracts/api-v1.yaml. |

Reconciliation: 10 HTTP entry points before audit, 3 removed framework extras, 7 retained routes after audit. All 7 retained routes serve the UC.1 workflow or its already-modeled configuration/status context. The four internal contract operations are in-process methods, not extra HTTP endpoints. A runtime route-set test rejects unlisted routes.

## Browser and command inventory

| User-triggered surface / command | Trace and disposition |
|---|---|
| walking_skeleton/frontend/index.html comparison submit | POST /compare, legacy UC.1 fixture. |
| walking_skeleton/frontend/research.html comparison submit | POST /research/compare, current F.1–F.5 path. |
| Returned source links | GET /research/evidence/{source_id}, UC.1.8 / UC.1.C inspection. |
| walking_skeleton/browser/index.html submit, built .site/skeleton.html mirror | Same UC.1 fixed fixture, browser-only educational mirror; not a separate backend route. |
| python -m walking_skeleton | Starts the same loopback server; A-06 operating support. |
| scripts/check_http.py and scripts/check_ch4_http.py | Verification clients of the listed endpoints; A-04/V-111/V-125 support, not separate business entry points. |
| scripts/run_ch4_verification.py, verify.py, check_baseline.py | Requirement/model verification commands, A-04/A-05 support. |
| scripts/create_ch4_verification_fixture.py, finalize_ch4_evidence.py | Produce explicitly synthetic verification records; A-04 support, not customer features. |
| scripts/record_stakeholder_assessment.py, report_acceptance.py | Capture/check actual assessment evidence under A-05/A-06; no fabricated stakeholder records generated. |
| scripts/build_site.py and static-file preview command | Build/serve the retained educational mirror, A-04/A-06 support. |
| scripts/generate_internal_stubs.py | Contract-derived build tool, A-05 configuration/traceability support; emits signatures/client only. |
| Historical-sandbox date/stock selection and ranking | Removed from delivered website: allowed 2–5 symbols and a different scoring basis; not the authorized two-stock/frozen-universe workflow. |
| Historical-sandbox weight sliders | Removed: changing sentiment weights was an unmodeled domain command, not IO.10's authorized configuration. |
| Historical-sandbox reveal/hide future returns | Removed: no use case authorizes evaluating subsequent returns in this increment. |
| Historical-sandbox view navigation | Replaced by static course navigation; dead interactive scripts removed. |

No orphan business operation remains in this delivered product copy. Read-only static documentation links are navigation, not an additional domain operation. Four legacy interactive control groups and three automatically exposed documentation routes were the audit findings; their origin was the inherited exploratory website/framework defaults, not newly requested features.

## Use cases without product entry points

UC.1 has the listed HTTP/UI paths. Its included driver/source inspection behaviors are performed by the user over displayed results and source links; no separate calculation endpoint is invented for human inspection. Live market/news/AI service integration and independent human assessment remain planned, rather than passed. Lifecycle actions A-04–A-08 are support obligations and are not miscounted as additional research-use-case routes. All owner/team review claims require actual human confirmation.
