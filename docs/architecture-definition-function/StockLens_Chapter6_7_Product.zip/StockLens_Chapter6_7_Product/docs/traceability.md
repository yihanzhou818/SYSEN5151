# Chapter 4–5 function / requirement / module / test traceability

This is the top-level context architecture actually saved in Innoslate, not a newly invented internal decomposition. External roles are represented by injected adapters; their controlled doubles do not prove live external-service integration. The composition helper runtime.py is not an extra model function.

| Function / native ID | Exact model name | Named module | Mechanism / requirements | Tests |
|---|---|---|---|---|
| F.0 / 264782 | Provide Stock Comparisons | `functional_architecture/provide_stock_comparisons.py` | StockLens System; 1.4.1 | `tests/test_system_requirements.py` requirement-ID cases |
| EF.1 / 264786 | Request and Review Stock Research | `functional_architecture/request_and_review_stock_research.py` | X.01 Research User; 1.1.1 / 1.2.1 / 1.3.1 | `tests/test_system_requirements.py` requirement-ID cases |
| EF.2 / 264789 | Supply Dated Market Records | `functional_architecture/supply_dated_market_records.py` | X.02 Market Data Provider; 1.1.2 / 1.2.2 / 1.3.2 | `tests/test_system_requirements.py` requirement-ID cases |
| EF.3 / 264790 | Supply Dated News Evidence | `functional_architecture/supply_dated_news_evidence.py` | X.03 News Provider; 1.1.3 / 1.2.3 / 1.3.3 | `tests/test_system_requirements.py` requirement-ID cases |
| EF.4 / 264792 | Generate Grounded Explanation Text | `functional_architecture/generate_grounded_explanation_text.py` | X.04 AI Model Service; 1.1.4 / 1.2.4 / 1.3.4 | `tests/test_system_requirements.py` requirement-ID cases |
| EF.5 / 264793 | Configure and Monitor Research Service | `functional_architecture/configure_and_monitor_research_service.py` | X.05 System Maintainer; 1.1.5 / 1.2.5 / 1.3.5 | `tests/test_system_requirements.py` requirement-ID cases |

The original fifteen generated shall statements plus manual top requirement 264940 are retained verbatim in model-artifacts/ch4-ch5/native-requirements-and-cases.json. Detailed per-requirement test names and native verdicts are generated in evidence/ch4-ch5/requirements-results.json. Inputs/outputs are positional transformed data; research_configuration and mechanisms are keyword-only controls/dependencies. EF.2–EF.4 queries/package are controls as shown on the context diagram.

## API / use-case mapping

| Endpoint | Model / requirement | Scope |
|---|---|---|
| `GET /research` | EF.1; UC.1.1/1.7/1.8; 1.3.1 | Controlled research form and result display |
| `POST /research/compare` | F.0; UC.1.2–1.7; 1.1.1 / 1.2.1 / 1.4.1 | Synthetic verification snapshot only |
| `GET /research/status` | F.0 / EF.5; IO.06; 1.2.5 | Actual local runtime state |
| `POST /research/configuration` | EF.5; IO.10; 1.1.5 / 1.3.5 | Validated atomic local configuration |
| `GET /research/evidence/{source_id}` | EF.1 / EF.3; IO.02/08; 1.1.3 / 1.2.1 | Inspectable synthetic source; no real article impersonation |

Legacy `/` and `/compare` retain the fixed walking-skeleton behavior and existing tests; they are not the new requirement-complete path.
