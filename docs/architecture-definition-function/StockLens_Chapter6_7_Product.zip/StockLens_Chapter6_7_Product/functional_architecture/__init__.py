"""Executable Chapter 4 context architecture; verification snapshots are explicit."""
