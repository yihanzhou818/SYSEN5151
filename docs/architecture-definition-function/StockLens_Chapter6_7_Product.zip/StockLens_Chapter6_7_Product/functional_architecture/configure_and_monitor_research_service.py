"""EF.5 / 264793. IO.06 status input -> IO.10 configuration control output.
Mechanism X.05 is injected; no independent human handover is inferred.
"""
from copy import deepcopy
from .contracts import validate_config,ContractError

def configure_and_monitor_research_service(service_status,*,research_configuration,mechanism):
    candidate=validate_config(research_configuration)
    if service_status.get('configuration_version')!=candidate['version']:
        raise ContractError('status/configuration version mismatch')
    return deepcopy(candidate)
