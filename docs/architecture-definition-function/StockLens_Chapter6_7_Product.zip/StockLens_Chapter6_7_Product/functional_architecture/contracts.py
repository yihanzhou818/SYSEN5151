"""Shared internal types. Local verification protocol, not an approved vendor API."""
from copy import deepcopy
from datetime import date, datetime, timedelta
import math

SYMBOLS = ('AAPL','MSFT','AMZN','GOOGL','META','NVDA','TSLA','JPM','JNJ','XOM')
CONFIG = {'version':'user-approved-v0.1','universe':list(SYMBOLS),'window':20,
          'weights':{'momentum':0.5,'low_volatility':0.5},'news_days':7,'news_limit':2,
          'score_tolerance':1e-6,'ai_attempts':2,'ai_timeout_seconds':20,
          'trial_budget_usd':5,'data_mode':'synthetic-verification'}

class ContractError(ValueError):
    pass

class ServiceUnavailable(RuntimeError):
    pass


def validate_config(value):
    """IO.10 control; changes are atomic, versioned and constrained to reviewed values."""
    if not isinstance(value,dict) or set(value)!=set(CONFIG):
        raise ContractError('configuration keys differ from the local verification contract')
    if not isinstance(value['version'],str) or not value['version'].strip():
        raise ContractError('configuration version is required')
    for key in CONFIG:
        if key!='version' and value[key]!=CONFIG[key]:
            raise ContractError(f'unsupported configuration setting: {key}')
    return deepcopy(value)


def request_pair(query,config):
    validate_config(config)
    if not isinstance(query,dict) or set(query)!={'stock_pair','analysis_date','cutoff_at'}:
        raise ContractError('request requires stock_pair, analysis_date and cutoff_at')
    pair=query['stock_pair']
    if not isinstance(pair,list) or len(pair)!=2 or any(not isinstance(s,str) for s in pair):
        raise ContractError('exactly two string symbols are required')
    if pair[0]==pair[1] or any(s not in config['universe'] for s in pair):
        raise ContractError('distinct eligible symbols are required')
    try:
        day=date.fromisoformat(query['analysis_date'])
        cutoff=datetime.fromisoformat(query['cutoff_at'])
    except (ValueError,TypeError):
        raise ContractError('invalid date or cutoff') from None
    if cutoff.tzinfo is None or cutoff.date()!=day:
        raise ContractError('cutoff must carry a timezone and the analysis date')
    return deepcopy(query)


def status(state,config,reason=None):
    if state not in {'ready','processing','completed','completed_with_limitations','failed'}:
        raise ContractError('unknown service state')
    return {'state':state,'configuration_version':config['version'],'reason':reason,
            'mode':config['data_mode']}


class ConfigurationStore:
    def __init__(self,config=None):
        self.configuration=validate_config(CONFIG if config is None else config)
        self.service_status=status('ready',self.configuration)

    def apply(self,candidate):
        validated=validate_config(candidate)
        self.configuration=validated
        self.service_status=status('ready',validated)
        return deepcopy(self.service_status)
