"""EF.4 / 264792. IO.05 package control -> IO.09 explanation; X.04 injected.
This module never computes rankings. Vendor/model/access remain unselected.
"""
from copy import deepcopy
from .contracts import ServiceUnavailable,ContractError

def canonical_text(package):
    return ' | '.join(f"{r['symbol']}: score={r['score']:.6f}, momentum={r['momentum']:.6f}, volatility={r['volatility']:.6f}" for r in package['scores'])

def generate_grounded_explanation_text(*,score_evidence_package,mechanism):
    if mechanism is None:
        raise ServiceUnavailable('no external AI service/model/access selected')
    before=deepcopy(score_evidence_package)
    response=mechanism(deepcopy(score_evidence_package))
    if score_evidence_package!=before:
        raise ContractError('AI mechanism changed the checked package')
    if not isinstance(response,dict) or set(response)!={'comparison_id','text','source_ids','mode'}:
        raise ContractError('local verification response schema mismatch')
    if response['comparison_id']!=before['comparison_id'] or response['text']!=canonical_text(before):
        raise ContractError('response contradicts checked numeric content or comparison identity')
    if response['source_ids']!=[s['id'] for s in before['sources']] or response['mode']!='synthetic-verification':
        raise ContractError('source association or verification mode mismatch')
    return deepcopy(response)
