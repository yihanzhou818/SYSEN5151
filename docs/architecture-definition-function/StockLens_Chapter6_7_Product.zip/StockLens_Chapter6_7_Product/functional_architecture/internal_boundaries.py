"""F.1–F.5 / 269034–269038: implementations behind model-derived contract v1.
Synthetic providers are injected; IO.10 remains a configuration control.
"""
from copy import deepcopy
import hashlib
import importlib
import json
from pathlib import Path
from statistics import stdev
from jsonschema import Draft202012Validator, FormatChecker, ValidationError
from contracts.generated.internal import InternalClient
from .contracts import ContractError, ServiceUnavailable, request_pair, status, validate_config
from .supply_dated_market_records import supply_dated_market_records
from .supply_dated_news_evidence import supply_dated_news_evidence
from .generate_grounded_explanation_text import generate_grounded_explanation_text

SPEC = json.loads((Path(__file__).resolve().parents[1]/'contracts/api-v1.yaml').read_text())
VALIDATORS = {name: Draft202012Validator({'$ref':'#/components/schemas/'+name,'components':SPEC['components']}, format_checker=FormatChecker()) for name in SPEC['components']['schemas']}

def validate(schema, value):
    try:
        VALIDATORS[schema].validate(value)
    except ValidationError as error:
        raise ContractError(f'{schema}: {error.message}') from error

class FunctionalServer:
    def __init__(self, config, market, news, ai=None):
        self.config = validate_config(config)
        self.market, self.news, self.ai = market, news, ai
        self.market_query = self.news_query = None
        self.trace = []

    def accept_request(self, query):
        """F.1 / 269034 produces IF.01; no physical mechanism is allocated."""
        result = {'query':request_pair(query,self.config),'configuration_version':self.config['version']}
        validate('ValidatedRequest',result)
        self.trace.append('F.1')
        return result

    def _version(self, request):
        if request['configuration_version'] != self.config['version']:
            raise ContractError('configuration control version differs across handoff')

    def acquire_evidence(self, request):
        """F.2 / 269035: IF.01 -> IF.02; distinct news and market queries."""
        self._version(request)
        legacy=importlib.import_module('.provide_stock_comparisons',__package__)
        self.market_query,self.news_query=legacy.queries(request['query'],self.config)
        news=supply_dated_news_evidence(news_query=self.news_query,mechanism=self.news)
        market=supply_dated_market_records(market_query=self.market_query,mechanism=self.market)
        # Provider-only calendar commentary stays with raw fixture evidence.
        market={k:market[k] for k in ('mode','source','currency','trading_dates','prices')}
        self.trace.append('F.2')
        return {'request':deepcopy(request),'market':market,'news':news}

    def calculate_ranking(self, evidence):
        """F.3 / 269036 produces one authoritative IF.03 for F.4 and F.5."""
        request=evidence['request'];self._version(request)
        query=request['query'];market=evidence['market'];factors={}
        # Validate semantic date/universe constraints even for independent callers.
        legacy=importlib.import_module('.provide_stock_comparisons',__package__)
        mq,_=legacy.queries(query,self.config)
        supply_dated_market_records(market_query=mq,mechanism=lambda _:market)
        for symbol,prices in market['prices'].items():
            returns=[b/a-1 for a,b in zip(prices,prices[1:])]
            factors[symbol]={'momentum':prices[-1]/prices[0]-1,'volatility':stdev(returns)}
        mr=legacy.average_ranks({s:f['momentum'] for s,f in factors.items()})
        vr=legacy.average_ranks({s:f['volatility'] for s,f in factors.items()})
        n=len(factors);scores=[]
        for symbol in query['stock_pair']:
            m=100*(mr[symbol]-1)/(n-1);v=100*(n-vr[symbol])/(n-1)
            scores.append({'symbol':symbol,**factors[symbol],'momentum_score':m,'low_volatility_score':v,'contributions':{'momentum':.5*m,'low_volatility':.5*v},'score':.5*m+.5*v})
        cid=hashlib.sha256(json.dumps([query,self.config],sort_keys=True).encode()).hexdigest()[:20]
        package={'comparison_id':cid,'analysis_date':query['analysis_date'],'cutoff_at':query['cutoff_at'],'configuration_version':self.config['version'],'scores':scores,'sources':deepcopy(evidence['news'])}
        diff={k:scores[0]['contributions'][k]-scores[1]['contributions'][k] for k in ('momentum','low_volatility')}
        self.trace.append('F.3')
        return {'request':deepcopy(request),'observation_date':market['trading_dates'][-1],'package':package,'driver_order':sorted(diff,key=lambda k:(-abs(diff[k]),k)),'driver_differences':diff,'tied':abs(scores[0]['score']-scores[1]['score'])<=self.config['score_tolerance']}

    def check_explanation(self, computed):
        """F.4 / 269037: IF.03 -> IO.05/09 -> IF.04; never recalculate scores."""
        self._version(computed['request']);response=None
        if self.ai is not None:
            for _ in range(self.config['ai_attempts']):
                try:
                    response=generate_grounded_explanation_text(score_evidence_package=deepcopy(computed['package']),mechanism=self.ai)
                    break
                except (ServiceUnavailable,ContractError,TimeoutError):
                    continue
        self.trace.append('F.4')
        return {'comparison_id':computed['package']['comparison_id'],'availability':'available' if response is not None else 'unavailable','explanation':response}

    def present_comparison(self, request):
        """F.5 / 269038 joins IF.03 and IF.04; checks identity and sources."""
        computed,checked=request['computed'],request['checked'];self._version(computed['request'])
        package=computed['package'];query=computed['request']['query']
        if checked['comparison_id']!=package['comparison_id']:
            raise ContractError('explanation and score record belong to different comparisons')
        if package['configuration_version']!=self.config['version'] or package['analysis_date']!=query['analysis_date']:
            raise ContractError('computed record version/date does not match request')
        if [r['symbol'] for r in package['scores']]!=query['stock_pair']:
            raise ContractError('score record symbols do not match request')
        if (checked['availability']=='available') != (checked['explanation'] is not None):
            raise ContractError('availability contradicts explanation content')
        explanation=checked['explanation']
        if explanation is not None:
            generate_grounded_explanation_text(score_evidence_package=package,mechanism=lambda _:explanation)
        self.trace.append('F.5')
        return {'comparison_id':package['comparison_id'],'requested_query':deepcopy(query),'configuration_version':package['configuration_version'],'analysis_date':package['analysis_date'],'observation_date':computed['observation_date'],'scores':deepcopy(package['scores']),'driver_order':computed['driver_order'],'driver_differences':computed['driver_differences'],'sources':deepcopy(package['sources']),'explanation':deepcopy(explanation),'tied':computed['tied'],'mode':'synthetic-verification','notice':'Controlled synthetic verification data; not actual market prices or news.'}

    def compare(self, query):
        client=InternalClient(self,validate)
        validated=self.accept_request(query)
        evidence=client.acquire_evidence(validated)
        computed=client.calculate_ranking(evidence)
        # Both destinations receive independent copies of the same IF.03 values.
        checked=client.check_explanation(deepcopy(computed))
        view=client.present_comparison({'computed':deepcopy(computed),'checked':checked})
        state='completed' if view['explanation'] is not None and view['sources'] else 'completed_with_limitations'
        reason=None if state=='completed' else 'AI explanation unavailable or no qualifying news evidence'
        return {'comparison_and_evidence':view,'market_query':deepcopy(self.market_query),'news_query':deepcopy(self.news_query),'score_evidence_package':deepcopy(computed['package']),'service_status':status(state,self.config,reason)}
