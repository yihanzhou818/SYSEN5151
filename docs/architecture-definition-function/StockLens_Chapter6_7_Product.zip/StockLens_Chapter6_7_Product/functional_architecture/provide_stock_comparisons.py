"""F.0 / 264782; requirement 1.4.1 / 264940.
Transformed inputs: IO.01 query, IO.07 market records, IO.08 news, IO.09 AI text.
Control: keyword-only IO.10 research_configuration. Mechanism: injected StockLens.
Returns IO.02 comparison/evidence, IO.03/04 queries, IO.05 package, IO.06 status.
"""
from copy import deepcopy
from statistics import stdev
import hashlib,json
from .contracts import request_pair,status,ContractError
from .supply_dated_market_records import supply_dated_market_records
from .supply_dated_news_evidence import supply_dated_news_evidence

def average_ranks(values):
    keys=sorted(values,key=lambda k:values[k]);ranks={};i=0
    while i<len(keys):
        j=i+1
        while j<len(keys) and values[keys[j]]==values[keys[i]]:j+=1
        for key in keys[i:j]:ranks[key]=(i+1+j)/2
        i=j
    return ranks


def queries(query,configuration):
    request_pair(query,configuration)
    return ({'stock_pair':deepcopy(query['stock_pair']),'analysis_date':query['analysis_date'],
             'universe':deepcopy(configuration['universe']),'window':configuration['window']},
            {'stock_pair':deepcopy(query['stock_pair']),'cutoff_at':query['cutoff_at'],
             'days':configuration['news_days'],'limit_per_stock':configuration['news_limit']})


def provide_stock_comparisons(stock_pair_date,dated_market_records,dated_news_evidence,ai_explanation_text,*,research_configuration,mechanism):
    """Retained F.0 facade; internal responsibilities now follow contract v1."""
    from .internal_boundaries import FunctionalServer
    ai = None if ai_explanation_text is None else lambda _: deepcopy(ai_explanation_text)
    server=FunctionalServer(research_configuration,lambda _:deepcopy(dated_market_records),lambda _:deepcopy(dated_news_evidence),ai)
    return server.compare(stock_pair_date)
