"""EF.1 / 264786. IO.02 comparison input; IO.01 request output; X.01 injected.
This adapter is executable; a software caller is not evidence of human comprehension.
"""
from copy import deepcopy
from .contracts import request_pair,ContractError

def request_and_review_stock_research(stock_pair_date,comparison_and_evidence=None,*,research_configuration,mechanism):
    query=request_pair(stock_pair_date,research_configuration)
    if comparison_and_evidence is not None and comparison_and_evidence['requested_query']!=query:
        raise ContractError('result belongs to another request')
    return {'stock_pair_date':query,'comparison_and_evidence':deepcopy(comparison_and_evidence)}
