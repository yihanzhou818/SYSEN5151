"""Composition of the six mapped functions; not an extra top-level model function."""
from copy import deepcopy
from .contracts import CONFIG,ConfigurationStore,ContractError,ServiceUnavailable,status,request_pair
from .provide_stock_comparisons import queries,provide_stock_comparisons
from .supply_dated_market_records import supply_dated_market_records
from .supply_dated_news_evidence import supply_dated_news_evidence
from .generate_grounded_explanation_text import generate_grounded_explanation_text
from .request_and_review_stock_research import request_and_review_stock_research
from .configure_and_monitor_research_service import configure_and_monitor_research_service

class ResearchRuntime:
    def __init__(self,market,news,ai=None):
        self.store=ConfigurationStore();self.market=market;self.news=news;self.ai=ai;self.ai_calls=0

    def compare(self,query):
        config=deepcopy(self.store.configuration)
        self.store.service_status=status('processing',config)
        try:
            request_and_review_stock_research(query,research_configuration=config,mechanism='controlled API caller')
            from .internal_boundaries import FunctionalServer
            def counted_ai(package):
                self.ai_calls += 1
                return self.ai(package)
            server=FunctionalServer(config,self.market,self.news,None if self.ai is None else counted_ai)
            result=server.compare(query)
            self.last_internal_trace=server.trace
            request_and_review_stock_research(query,result['comparison_and_evidence'],research_configuration=config,mechanism='controlled API caller')
            self.store.service_status=result['service_status']
            return result
        except (ContractError,ValueError,ServiceUnavailable,TimeoutError) as error:
            self.store.service_status=status('failed',config,str(error))
            raise

    def configure(self,candidate):
        result=self.store.apply(candidate)
        configure_and_monitor_research_service(result,research_configuration=self.store.configuration,mechanism='controlled API caller')
        return result
