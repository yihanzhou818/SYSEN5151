"""EF.2 / 264789. IO.03 is query control; IO.07 is returned output.
Mechanism: injected X.02 Market Data Provider; no live provider is impersonated.
"""
from copy import deepcopy
from datetime import date
import math
from .contracts import ContractError

def supply_dated_market_records(*,market_query,mechanism):
    records=deepcopy(mechanism(market_query))
    if records.get('mode')!='synthetic-verification' or not records.get('source'):
        raise ContractError('a labelled, attributable verification snapshot is required')
    dates=records.get('trading_dates',[])
    try:
        parsed=[date.fromisoformat(d) for d in dates]
    except (ValueError,TypeError):
        raise ContractError('invalid observation date') from None
    if len(dates)!=21 or parsed!=sorted(set(parsed)) or dates[-1]!=market_query['analysis_date']:
        raise ContractError('21 aligned observations ending on the analysis date are required')
    if set(records.get('prices',{}))!=set(market_query['universe']):
        raise ContractError('normalization requires the complete fixed universe')
    for prices in records['prices'].values():
        if len(prices)!=21 or any(isinstance(p,bool) or not isinstance(p,(int,float)) or not math.isfinite(p) or p<=0 for p in prices):
            raise ContractError('missing, nonfinite or nonpositive price; no imputation')
    if not records.get('currency'):
        raise ContractError('price currency is required')
    return records
