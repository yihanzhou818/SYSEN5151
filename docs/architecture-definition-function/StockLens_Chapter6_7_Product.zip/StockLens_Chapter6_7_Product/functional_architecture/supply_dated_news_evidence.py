"""EF.3 / 264790. Query control IO.04; evidence output IO.08; X.03 injected."""
from copy import deepcopy
from datetime import datetime,timedelta
from .contracts import ContractError

def supply_dated_news_evidence(*,news_query,mechanism):
    cutoff=datetime.fromisoformat(news_query['cutoff_at'])
    start=cutoff-timedelta(days=news_query['days'])
    selected=[];seen=set();counts={s:0 for s in news_query['stock_pair']}
    items=deepcopy(mechanism(news_query))
    for item in items:
        if not all(k in item for k in ('id','symbol','published_at','url','title','excerpt','supporting_text','mode')):
            raise ContractError('news provenance/content field missing')
        try:
            published=datetime.fromisoformat(item['published_at'])
        except (ValueError,TypeError):
            raise ContractError('invalid news publication timestamp') from None
        if published.tzinfo is None:
            raise ContractError('publication timezone required')
        if item['id'] in seen:
            raise ContractError('duplicate source identifier')
        seen.add(item['id'])
        if item['symbol'] not in counts or not start<=published<=cutoff:
            continue
        if item['mode']!='synthetic-verification' or not item['url'].startswith('/research/evidence/'):
            raise ContractError('verification source must be labelled and locally inspectable')
        if not item['excerpt'] or item['excerpt'] not in item['supporting_text']:
            raise ContractError('the source does not support the supplied claim')
        selected.append(item)
    selected.sort(key=lambda item:(item['published_at'],item['id']),reverse=True)
    result=[]
    for item in selected:
        if counts[item['symbol']]<news_query['limit_per_stock']:
            result.append(item);counts[item['symbol']]+=1
    return result
