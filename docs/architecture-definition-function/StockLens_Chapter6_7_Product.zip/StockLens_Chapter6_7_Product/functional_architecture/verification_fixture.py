"""Explicit controlled inputs for local verification; real providers remain unselected."""
import json
from pathlib import Path
from copy import deepcopy
from .runtime import ResearchRuntime

def fixture_data():
    return json.loads((Path(__file__).resolve().parents[1]/'tests/fixtures/ch4_ch5/synthetic_snapshot.json').read_text())

def verification_runtime():
    data=fixture_data()
    return ResearchRuntime(lambda _:deepcopy(data['market']),lambda _:deepcopy(data['news']),None)
