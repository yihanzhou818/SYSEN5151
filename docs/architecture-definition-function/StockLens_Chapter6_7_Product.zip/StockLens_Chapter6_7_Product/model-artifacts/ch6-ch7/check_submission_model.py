"""Submission audit of saved native UI records; no network or model mutations."""
import json,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
core=json.loads(subprocess.check_output([sys.executable,str(p/'check_consistency.py')],text=True))
checks=core['checks'][:]
f=json.loads((p/'functions-verified.json').read_text());d=json.loads((p/'derived-flows-final.json').read_text());c=json.loads((p/'context-functions-final.json').read_text())
by={x['url'].split('/')[-1]:x for x in f+c+d}
def links(r,kind):return {e['href'].split('/')[-1] for a in r['relations'] if a['type']==kind for e in a['entities']}
def check(name,value):checks.append({'check':name,'passed':bool(value)})
for i in ['269043','269044','269045','269046','269047','269048','269050','269051','269052','269053','186194','269054','186307','186192']:check(i+'_direct_requirement_trace',bool(links(by[i],'satisfies')))
for r in d:check(r['url'].split('/')[-1]+'_flow_requirement_trace',bool(links(r,'satisfies')))
for r in c[1:]:check(r['number']+'_one_context_mechanism',len(links(r,'performed by'))==1)
root=by['264782'];first=[by[i] for i in links(root,'decomposed by')]
for kind in ['receives','generates']:check('all_root_'+kind+'_carried_down',links(root,kind)<=set().union(*(links(x,kind) for x in first)))
context_in=set().union(*(links(x,'receives') for x in c[1:]));context_out=set().union(*(links(x,'generates') for x in c[1:]))
check('all_context_ICOM_has_source_and_destination',context_in==context_out)
expected={'269039':({'269034'},{'269035'}),'269040':({'269035'},{'269036'}),'269041':({'269036'},{'269037','269038'}),'269042':({'269037'},{'269038'})}
check('four_internal_flows_five_exact_first_level_edges',all(({x['url'].split('/')[-1] for x in first if fid in links(x,'generates')},{x['url'].split('/')[-1] for x in first if fid in links(x,'receives')})==pair for fid,pair in expected.items()))
result={'checks':checks,'passed':all(x['passed'] for x in checks),'total':len(checks),'scope':'Saved current assignment model only; native global heuristic findings have separate dispositions.'}
print(json.dumps(result,indent=2));raise SystemExit(0 if result['passed'] else 1)
