# Chapter 4–5 requirement-driven increment

## LOCATE / EXTRACT
Source: native Innoslate project 659, MF.0 264781, F.0 264782, EF.1–EF.5 264786/264789/264790/264792/264793; requirements 264890–264904 and 264940, case IDs 267725–267740. Exact exports are retained in model-artifacts/ch4-ch5/.
The current e908359 walking skeleton is a fixed fixture. It does not implement calculation or maintenance. Preserve it as an explicitly labelled legacy demonstration.

## CONSTRAIN
User explicitly approved the definite values in candidate P-01–P-11 on 2026-10-18 in the Codex task; recording this instruction is not independent team/stakeholder acceptance. Unselected providers, AI service/model/schema details, human participants/operators and risk owners remain unresolved. Implement the approved deterministic ten-symbol, 20-return, 50/50 momentum/volatility rule with explicit cutoff and failure handling. Use standard-library code for the new engine. Do not buy services, invent market prices/news or mark external/human assessments complete. Controlled synthetic verification inputs must be prominently labelled and never relabelled as actual observations.

## PROMPT / allowed changes
Create one named module for each context function; signatures distinguish transformed inputs, controls and injected mechanisms. Add function/IO/interface requirement records, module and test mappings, meaningful independent-oracle tests and CI. Add a separate local research API while retaining the legacy `/compare` fixture contract. Record actual baseline failures, implementation results, limitations and requirement-level verdicts. Do not edit submitted stakeholder statement text or weaken its strict assessment scaffold. No live data or AI credentials are available.

## Acceptance before GENERATE
- Exact 16 native requirement identifiers; one F.0 functional obligation.
- 10-stock/21-positive-price coverage; independent rank/momentum/sample-volatility arithmetic; equal-factor and tie cases; no imputation or look-ahead publication leakage.
- AI text never sets scores; malformed, contradictory or unavailable responses yield a declared limited result.
- Configuration validated atomically and versioned; resulting state/status is inspectable.
- Test suite executes every requirement-labelled case, distinguishes controlled conformance from external/human evidence, and fails CI when a functional implementation assertion fails.
- Full acceptance/human/provider gaps remain explicit; no fake Pass.

## REVIEW / RECONCILE
To be completed with actual commands, exit codes, before/after counts and model reconciliation after execution.

## Actual REVIEW / RECONCILE record

- 22 model-derived controlled checks pass, including all 16 native requirement IDs; independent Decimal/direct-rank oracle is used for scoring.
- Full development verification passes: 26 Python tests, 3 Node checks, submitted-baseline transcription and the legacy real HTTP smoke check. New real HTTP checks and 20 offline timing requests pass; measured nearest-rank P95 is retained in http-results.json (not an external-AI measurement).
- A deliberate wrong-rank injection causes V-141 to fail; no persisted implementation or test change is used to accommodate it.
- Original strict stakeholder scaffold was actually executed: 8 checks fail for absent full evidence. This is not an observed failure of eight participant studies. It has not been weakened; the new CI includes a separate failing strict-evidence job.
- Source and role controls, no-imputation, timestamp/source filtering, local configuration acceptance/rejection and state/version association are implemented. Native full-scope verdicts close only V-111 and V-125 for the documented local boundary; 14 remaining full plans are not assessed even though their controlled subtests ran successfully.
- Production data/provider/AI model/schema/access, live timeout/budget enforcement and human operation/assessment remain open. Controlled doubles and synthetic sources cannot close them. No live-service calls or payments occurred.
