# Saved system requirements and actual verification scope

Exact statement sources: Innoslate project 659; saved native exports in model-artifacts/ch4-ch5/. A Pass below closes only the stated local boundary verification case, not stakeholder validation. User approval covers definite v0.1 values; named services, vendor contracts and independent human work remain unselected/unobserved.

| Requirement / entity | Test / native case | Controlled result | Native full-case verdict and reason |
|---|---|---|---|
| 1.1.1 / 264904 | `test_system_requirements.SystemRequirementTests.test_REQ_1_1_1_V111_accept_pair_and_date`; V-111 / 267725 | Passed | Passed: Controlled V-111 plus real HTTP input preservation, ten-symbol eligibility, duplicate/unknown/date rejection. Scope: approved local synthetic verification configuration; no real-provider or stakeholder claim. |
| 1.1.2 / 264903 | `test_system_requirements.SystemRequirementTests.test_REQ_1_1_2_V112_dated_market_coverage`; V-112 / 267726 | Passed | Not Run: No selected real market provider/schema/units or actual-use record; controlled snapshot contract passed. |
| 1.1.3 / 264902 | `test_system_requirements.SystemRequirementTests.test_REQ_1_1_3_V113_news_source_support`; V-113 / 267727 | Passed | Not Run: Only self-authored synthetic source items inspected; real news provider/source conditions unselected. |
| 1.1.4 / 264901 | `test_system_requirements.SystemRequirementTests.test_REQ_1_1_4_V114_checked_explanation`; V-114 / 267728 | Passed | Not Run: Controlled canonical response passed; no selected AI/model/access or real generated-content assessment. |
| 1.1.5 / 264900 | `test_system_requirements.SystemRequirementTests.test_REQ_1_1_5_V115_configuration_atomic`; V-115 / 267729 | Passed | Not Run: Atomic local config passed; live-service/schema settings remain unselected. |
| 1.2.1 / 264899 | `test_system_requirements.SystemRequirementTests.test_REQ_1_2_1_V121_result_independent_oracle`; V-121 / 267730 | Passed | Not Run: Independent controlled scores/source links passed; intended real-source baseline and full AI content not assessed. |
| 1.2.2 / 264898 | `test_system_requirements.SystemRequirementTests.test_REQ_1_2_2_V122_market_query`; V-122 / 267731 | Passed | Not Run: Captured controlled query passed; real provider endpoint/permissions/contract unselected. |
| 1.2.3 / 264897 | `test_system_requirements.SystemRequirementTests.test_REQ_1_2_3_V123_news_query`; V-123 / 267732 | Passed | Not Run: Captured controlled news query passed; real source window/permissions/contract unselected. |
| 1.2.4 / 264896 | `test_system_requirements.SystemRequirementTests.test_REQ_1_2_4_V124_evidence_package_no_credentials`; V-124 / 267733 | Passed | Not Run: Local verification package passed; approved vendor field schema and service access remain unselected. |
| 1.2.5 / 264895 | `test_system_requirements.SystemRequirementTests.test_REQ_1_2_5_V125_status_outcomes`; V-125 / 267734 | Passed | Passed: Controlled V-125 plus real HTTP ready/failed/limited states, atomic configuration acceptance/rejection and applied-version correspondence. Scope: local maintainer API, not independent handover or production access control. |
| 1.3.1 / 264894 | `test_system_requirements.SystemRequirementTests.test_REQ_1_3_1_V131_user_request_result_association`; V-131 / 267735 | Passed | Not Run: Controlled API association passed; full user-facing production contract/browser interaction and real-source basis not assessed. |
| 1.3.2 / 264893 | `test_system_requirements.SystemRequirementTests.test_REQ_1_3_2_V132_market_interface_roundtrip`; V-132 / 267736 | Passed | Not Run: Controlled adapter roundtrip passed; real-provider conditions and integration unselected. |
| 1.3.3 / 264892 | `test_system_requirements.SystemRequirementTests.test_REQ_1_3_3_V133_news_interface_dates`; V-133 / 267737 | Passed | Not Run: Controlled date/provenance checks passed; real news provider and actual-use review unselected. |
| 1.3.4 / 264891 | `test_system_requirements.SystemRequirementTests.test_REQ_1_3_4_V134_ai_interface_fail_closed`; V-134 / 267738 | Passed | Not Run: Controlled malformed-response/retry tests passed; no real AI/model/access or approved vendor contract. |
| 1.3.5 / 264890 | `test_system_requirements.SystemRequirementTests.test_REQ_1_3_5_V135_automated_maintenance_cycle`; V-135 / 267739 | Passed | Not Run: Automated maintenance cycle passed; a non-author human has not executed the operating/handover guide. |
| 1.4.1 / 264940 | `test_system_requirements.SystemRequirementTests.test_REQ_1_4_1_V141_end_to_end_icom`; V-141 / 267740 | Passed | Not Run: Controlled end-to-end calculation passed; full V-141 source/AI baseline gates remain open. Not a live-system acceptance pass. |

## Exact shall statements

### 1.1.1 / 264904

The StockLens System shall accept Stock Pair and Date from the Research User.

### 1.1.2 / 264903

The StockLens System shall accept Dated Market Records from the Market Data Provider.

### 1.1.3 / 264902

The StockLens System shall accept Dated News Evidence from the News Provider.

### 1.1.4 / 264901

The StockLens System shall accept AI Explanation Text from the AI Model Service.

### 1.1.5 / 264900

The StockLens System shall accept Research Configuration from the System Maintainer.

### 1.2.1 / 264899

The StockLens System shall provide Comparison and Evidence to the Research User.

### 1.2.2 / 264898

The StockLens System shall provide Market Query to the Market Data Provider.

### 1.2.3 / 264897

The StockLens System shall provide News Query to the News Provider.

### 1.2.4 / 264896

The StockLens System shall provide Score-Evidence Package to the AI Model Service.

### 1.2.5 / 264895

The StockLens System shall provide Service Status to the System Maintainer.

### 1.3.1 / 264894

The StockLens System shall interface with the Research User through the User Research Interface.

### 1.3.2 / 264893

The StockLens System shall interface with the Market Data Provider through the Market Data Interface.

### 1.3.3 / 264892

The StockLens System shall interface with the News Provider through the News Interface.

### 1.3.4 / 264891

The StockLens System shall interface with the AI Model Service through the AI Analysis Interface.

### 1.3.5 / 264890

The StockLens System shall interface with the System Maintainer through the Maintenance Interface.

### 1.4.1 / 264940

The StockLens System shall provide evidence-linked comparisons of two eligible stocks using a common analysis date and a documented indicator and scoring configuration.

