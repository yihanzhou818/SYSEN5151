"""Real loopback HTTP checks and 20 offline timings; no external call or human study."""
import json,math,platform,socket,subprocess,sys,time
from pathlib import Path
from urllib.error import HTTPError,URLError
from urllib.request import Request,urlopen

def main():
    root=Path(__file__).resolve().parents[1]
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
    server=subprocess.Popen([sys.executable,'-m','uvicorn','walking_skeleton.backend.main:app','--host','127.0.0.1','--port',str(port),'--no-access-log'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    base=f'http://127.0.0.1:{port}';checks=[]
    def call(path,body=None,expected=200):
        req=Request(base+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
        try:
            with urlopen(req,timeout=5) as response:code=response.status;data=response.read()
        except HTTPError as error:code=error.code;data=error.read()
        assert code==expected,(path,code,data[:300])
        return data
    try:
        deadline=time.monotonic()+15
        while True:
            if server.poll() is not None:raise RuntimeError(server.stderr.read().decode())
            try:status=json.loads(call('/research/status'));break
            except (URLError,TimeoutError):
                if time.monotonic()>deadline:raise
                time.sleep(.1)
        query=status['verification_query'];payload={'stock_a':query['stock_pair'][0],'stock_b':query['stock_pair'][1],'analysis_date':query['analysis_date'],'cutoff_at':query['cutoff_at']}
        page=call('/research').decode();assert 'Controlled synthetic verification data' in page;checks.append('GET /research labelled page')
        out=json.loads(call('/research/compare',payload));assert out['comparison_and_evidence']['requested_query']==query;checks.append('V-111: real HTTP pair/date/cutoff preserved')
        assert out['service_status']['state']=='completed_with_limitations';assert out['comparison_and_evidence']['explanation'] is None;checks.append('unselected AI honestly unavailable')
        for source in out['comparison_and_evidence']['sources']:
            item=json.loads(call(source['url']));assert source['excerpt'] in item['supporting_text']
        checks.append('source links resolve to actual controlled evidence content')
        for bad in [{'stock_a':'UNKNOWN'},{'stock_b':payload['stock_a']},{'analysis_date':'bad-date'}]:call('/research/compare',{**payload,**bad},400)
        assert json.loads(call('/research/status'))['service_status']['state']=='failed';checks.append('V-125: invalid requests set actual failed state')
        before=json.loads(call('/research/status'))['configuration'];bad={**before,'window':0};call('/research/configuration',bad,400)
        assert json.loads(call('/research/status'))['configuration']==before
        changed={**before,'version':'http-verification-v0.1'};new=json.loads(call('/research/configuration',changed));assert new['state']=='ready' and new['configuration_version']==changed['version'];checks.append('atomic rejected/accepted config and correct version/status')
        timings=[]
        for _ in range(20):
            start=time.perf_counter();value=json.loads(call('/research/compare',payload));timings.append(time.perf_counter()-start)
            assert value['comparison_and_evidence']['configuration_version']==changed['version']
        p95=sorted(timings)[math.ceil(.95*len(timings))-1]
        assert p95<=3,'offline controlled target exceeded'
        record={'scope':'loopback HTTP; synthetic snapshot; no external AI/provider; no human validation',
                'python':platform.python_version(),'platform':platform.system()+' '+platform.release()+' '+platform.machine(),
                'checks':checks,'offline_seconds':timings,'n':20,'p95_seconds':p95,'statistic':'nearest-rank descriptive P95',
                'offline_target_seconds':3,'offline_target_met_in_this_run':True,
                'external_ai_timing':'not measured: no selected service/model/access',
                'actual_external_requests':0,'actual_external_cost_usd':0,'exit_code':0}
        target=root/'evidence/ch4-ch5/http-results.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record,indent=2))
    finally:
        server.terminate()
        try:server.wait(timeout=5)
        except subprocess.TimeoutExpired:server.kill();server.wait()
if __name__=='__main__':main()
