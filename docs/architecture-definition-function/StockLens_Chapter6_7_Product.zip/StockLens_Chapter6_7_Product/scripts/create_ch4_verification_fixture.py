"""Create artificial, attributable test inputs; never download or invent real prices."""
from datetime import date,timedelta,datetime,timezone
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from functional_architecture.contracts import SYMBOLS

def main():
    dates=[];day=date(2026,9,1)
    while len(dates)<21:
        if day.weekday()<5:dates.append(day.isoformat())
        day+=timedelta(days=1)
    prices={}
    for i,symbol in enumerate(SYMBOLS):
        values=[100.0];amp=.0003*[8,1,10,3,6,2,9,4,7,5][i]
        for k in range(20):values.append(values[-1]*(1+.001*(i+1)+(amp if k%2 else -amp)))
        prices[symbol]=values
    market={'mode':'synthetic-verification','source':'Course team controlled synthetic generator; no market-data provider',
            'currency':'USD (synthetic units)','trading_dates':dates,'prices':prices,
            'calendar_notice':'Artificial weekday ledger for contract verification; not an exchange-calendar approval.'}
    news=[]
    for symbol in SYMBOLS:
        source='SYNTH-'+symbol;text=f'Synthetic verification evidence for {symbol}; this is not a real news event.'
        news.append({'id':source,'symbol':symbol,'published_at':dates[-1]+'T12:00:00+00:00',
                     'url':'/research/evidence/'+source,'title':f'{symbol} synthetic source','excerpt':text,
                     'supporting_text':text,'mode':'synthetic-verification'})
    data={'notice':'Artificial test data. No prices, dates, news or external AI outcomes are asserted as real.',
          'query':{'stock_pair':['AAPL','MSFT'],'analysis_date':dates[-1],'cutoff_at':dates[-1]+'T20:00:00+00:00'},
          'market':market,'news':news}
    path=Path('tests/fixtures/ch4_ch5/synthetic_snapshot.json');path.write_text(json.dumps(data,indent=2)+'\n')
if __name__=='__main__':main()
