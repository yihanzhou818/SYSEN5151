"""Gate native full-case verdicts separately from controlled unit outcomes."""
from pathlib import Path
import json

def main():
    root=Path(__file__).resolve().parents[1];folder=root/'evidence/ch4-ch5'
    unit=json.loads((folder/'requirements-results.json').read_text());http=json.loads((folder/'http-results.json').read_text())
    if not unit['success'] or unit['tests_run']!=22 or len(unit['requirement_cases'])!=16 or http['exit_code']!=0:
        raise RuntimeError('Incomplete or failing controlled evidence; do not publish native verdicts')
    for row in unit['requirement_cases']:
        if row['requirement']=='1.1.1':
            row['native_full_case_status']='Passed';row['native_reason']='Controlled V-111 plus real HTTP input preservation, ten-symbol eligibility, duplicate/unknown/date rejection. Scope: approved local synthetic verification configuration; no real-provider or stakeholder claim.'
        elif row['requirement']=='1.2.5':
            row['native_full_case_status']='Passed';row['native_reason']='Controlled V-125 plus real HTTP ready/failed/limited states, atomic configuration acceptance/rejection and applied-version correspondence. Scope: local maintainer API, not independent handover or production access control.'
        row['evidence_paths']=['evidence/ch4-ch5/controlled-unit-tests.txt','evidence/ch4-ch5/requirements-results.json','evidence/ch4-ch5/http-results.json']
    unit['native_verdict_policy']='Only V-111 and V-125 full local-boundary criteria are closed by the recorded HTTP and unit evidence. Fourteen other native plans remain Not Run for their full planned scope, despite successful controlled subtests. No skipped/pending unit case is represented as passing.'
    strict=folder/'strict-stakeholder-result.json'
    unit['strict_stakeholder_assessment']=json.loads(strict.read_text()) if strict.exists() else {'executed':False,'reason':'Separate strict-assessment CI job; no result available in this checkout.'}
    (folder/'requirements-results.json').write_text(json.dumps(unit,indent=2)+'\n')
    statements=json.loads((root/'model-artifacts/ch4-ch5/native-saved-statements.json').read_text());names={r['id']:r for r in statements}
    text='# Saved system requirements and actual verification scope\n\nExact statement sources: Innoslate project 659; saved native exports in model-artifacts/ch4-ch5/. A Pass below closes only the stated local boundary verification case, not stakeholder validation. User approval covers definite v0.1 values; named services, vendor contracts and independent human work remain unselected/unobserved.\n\n| Requirement / entity | Test / native case | Controlled result | Native full-case verdict and reason |\n|---|---|---|---|\n'
    for row in unit['requirement_cases']:
        text+=f'| {row["requirement"]} / {row["entity"]} | `{row["test"]}`; {row["case"]} / {row["case_id"]} | {row["outcome"]} | {row["native_full_case_status"]}: {row["native_reason"]} |\n'
    text+='\n## Exact shall statements\n\n'
    import re
    for row in unit['requirement_cases']:text+=f'### {row["requirement"]} / {row["entity"]}\n\n'+re.sub('<[^>]+>','',names[row['entity']]['statement'])+'\n\n'
    (root/'requirements/SYSTEM-REQUIREMENTS.md').write_text(text)
    print('22 controlled checks passed; 16 requirement-ID cases executed; 2 native full local cases Passed; 14 full scopes not assessed; strict stakeholder scaffold 8 failures retained.')
if __name__=='__main__':main()
