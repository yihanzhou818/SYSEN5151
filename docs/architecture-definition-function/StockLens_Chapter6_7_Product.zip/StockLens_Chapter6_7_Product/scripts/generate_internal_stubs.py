"""Generate protocol/client from model-derived OpenAPI; never inspect application code."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
p=root/'contracts/api-v1.yaml';spec=json.loads(p.read_text());digest=hashlib.sha256(p.read_bytes()).hexdigest()
out=root/'contracts/generated';out.mkdir(exist_ok=True)
lines=['"""Generated from contracts/api-v1.yaml; do not edit by hand."""','from typing import Protocol','',f'CONTRACT_SHA256 = {digest!r}','','class InternalServer(Protocol):']
for item in spec['paths'].values():
 op=item['post'];lines.append(f"    def {op['operationId']}(self, request: dict) -> dict: ...")
lines+=['','class InternalClient:','    def __init__(self, server, validate):','        self.server = server','        self.validate = validate','']
for item in spec['paths'].values():
 op=item['post'];name=op['operationId'];req=op['requestBody']['content']['application/json']['schema']['$ref'].split('/')[-1];res=op['responses']['200']['content']['application/json']['schema']['$ref'].split('/')[-1]
 lines +=[f'    def {name}(self, request: dict) -> dict:',f'        self.validate({req!r}, request)',f'        result = self.server.{name}(request)',f'        self.validate({res!r}, result)','        return result','']
(out/'internal.py').write_text('\n'.join(lines).rstrip()+'\n');(out/'__init__.py').write_text('')
print('Generated 4 server signatures and 4 schema-enforcing client operations from contract',digest)
