"""Run (do not bypass) the original strict scaffold and retain its actual exit."""
import json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
result=subprocess.run([sys.executable,'-m','unittest','discover','-s','acceptance','-v'],cwd=root,capture_output=True,text=True)
text=result.stdout+result.stderr;folder=root/'evidence/ch4-ch5';folder.mkdir(parents=True,exist_ok=True)
(folder/'strict-stakeholder-assessment.txt').write_text(text)
ran=re.search(r'Ran (\d+) tests?',text);failed=re.search(r'failures=(\d+)',text)
(folder/'strict-stakeholder-result.json').write_text(json.dumps({'executed':True,'exit_code':result.returncode,
 'tests':int(ran[1]) if ran else None,'failures':int(failed[1]) if failed else 0,
 'scope':'Existing strict missing-evidence scaffold, not executed human validation. No test was weakened.'},indent=2)+'\n')
print(text);raise SystemExit(result.returncode)
