"""Execute requirement-ID cases and retain machine-readable actual results."""
import json,platform,re,sys,unittest
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
class RecordedResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.records=[]
    def addSuccess(self,test):
        super().addSuccess(test);self.records.append({'test':test.id(),'outcome':'Passed'})
    def addFailure(self,test,err):
        super().addFailure(test,err);self.records.append({'test':test.id(),'outcome':'Failed'})
    def addError(self,test,err):
        super().addError(test,err);self.records.append({'test':test.id(),'outcome':'Error'})
    def addSkip(self,test,reason):
        super().addSkip(test,reason);self.records.append({'test':test.id(),'outcome':'Skipped','reason':reason})
def main():
    suite=unittest.defaultTestLoader.discover(str(root/'tests'),pattern='test_system_requirements.py')
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordedResult).run(suite)
    native=json.loads((root/'model-artifacts/ch4-ch5/native-requirements-and-cases.json').read_text())
    bynum={x['number']:x for x in native};records=[]
    reasons={
    '1.1.2':'No selected real market provider/schema/units or actual-use record; controlled snapshot contract passed.',
    '1.1.3':'Only self-authored synthetic source items inspected; real news provider/source conditions unselected.',
    '1.1.4':'Controlled canonical response passed; no selected AI/model/access or real generated-content assessment.',
    '1.1.5':'Atomic local config passed; live-service/schema settings remain unselected.',
    '1.2.1':'Independent controlled scores/source links passed; intended real-source baseline and full AI content not assessed.',
    '1.2.2':'Captured controlled query passed; real provider endpoint/permissions/contract unselected.',
    '1.2.3':'Captured controlled news query passed; real source window/permissions/contract unselected.',
    '1.2.4':'Local verification package passed; approved vendor field schema and service access remain unselected.',
    '1.3.1':'Controlled API association passed; full user-facing production contract/browser interaction and real-source basis not assessed.',
    '1.3.2':'Controlled adapter roundtrip passed; real-provider conditions and integration unselected.',
    '1.3.3':'Controlled date/provenance checks passed; real news provider and actual-use review unselected.',
    '1.3.4':'Controlled malformed-response/retry tests passed; no real AI/model/access or approved vendor contract.',
    '1.3.5':'Automated maintenance cycle passed; a non-author human has not executed the operating/handover guide.',
    '1.4.1':'Controlled end-to-end calculation passed; full V-141 source/AI baseline gates remain open. Not a live-system acceptance pass.'}
    for observed in result.records:
        m=re.search(r'test_REQ_(\d)_(\d)_(\d)_',observed['test'])
        if not m:continue
        number='.'.join(m.groups());case=bynum[number]
        records.append({'requirement':number,'entity':case['id'],'case_id':case['case_id'],'case':case['case_number'],
                        **observed,'native_full_case_status':'Not Run','native_reason':reasons.get(number,'Awaiting real HTTP confirmation in this run.'),
                        'scope':'controlled synthetic inputs; injected external doubles; not stakeholder validation'})
    report={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'tests_run':result.testsRun,
            'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'success':result.wasSuccessful(),
            'requirement_cases':records,'additional_tests':[r for r in result.records if not re.search(r'test_REQ_',r['test'])],
            'limits':'Native full statuses require independent gating of HTTP evidence and real-service/human prerequisites.'}
    target=root/'evidence/ch4-ch5/requirements-results.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(report,indent=2)+'\n')
    return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
