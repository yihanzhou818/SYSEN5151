import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {transmitEvaluationRequest,renderComparisonDashboard} from '../walking_skeleton/browser/skeleton.js';
test('browser stub result matches Python participant path',()=>{
 const js=renderComparisonDashboard(transmitEvaluationRequest('DEMO_A','DEMO_B','2026-09-18'));
 const py=JSON.parse(execFileSync(process.env.PYTHON||(process.platform==='win32'?'python':'python3'),['-c',"import json; from walking_skeleton import dashboard_ui; print(json.dumps(dashboard_ui.render_comparison_dashboard(dashboard_ui.transmit_evaluation_request('DEMO_A','DEMO_B','2026-09-18'))))"],{encoding:'utf8'}));
 assert.deepEqual(js,py);
});
test('browser fixture retains request identity without relabelling fixed data',()=>{
 const result=renderComparisonDashboard(transmitEvaluationRequest('OTHER_A','OTHER_B','2020-01-01'));
 assert.deepEqual(result.requested_query.stock_pair,['OTHER_A','OTHER_B']);
 assert.deepEqual(result.ranking.stock_pair,['DEMO_A','DEMO_B']);
 assert.equal(result.ranking.analysis_date,'2026-09-18');
});
test('delivered website removes orphan domain controls and builds the retained mirror',()=>{
 const page=readFileSync(new URL('../website/index.html',import.meta.url),'utf8');
 for(const orphan of ['id="runBtn"','id="toggleReturns"','data-w=','./js/app.js'])assert.ok(!page.includes(orphan));
 execFileSync(process.env.PYTHON||'python3',['scripts/build_site.py'],{encoding:'utf8'});
 const built=readFileSync(new URL('../.site/skeleton.html',import.meta.url),'utf8');
 assert.ok(built.includes('./js/skeleton.js'));
 const js=readFileSync(new URL('../.site/js/skeleton.js',import.meta.url),'utf8');
 assert.ok(js.includes('DEMO_A'));
});
