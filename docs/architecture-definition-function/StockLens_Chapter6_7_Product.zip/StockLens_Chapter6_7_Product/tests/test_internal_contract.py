"""Chapter 7: real contract failure cases, fan-out and independent arithmetic."""
from copy import deepcopy
import hashlib,json,unittest
from pathlib import Path
from contracts.generated.internal import CONTRACT_SHA256,InternalClient
from functional_architecture.internal_boundaries import FunctionalServer,validate,SPEC
from functional_architecture.contracts import CONFIG,ContractError
from functional_architecture.verification_fixture import fixture_data
from test_system_requirements import controlled_ai,independent_scores

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.data=fixture_data();self.server=FunctionalServer(CONFIG,lambda _:deepcopy(self.data['market']),lambda _:deepcopy(self.data['news']),controlled_ai)
        self.client=InternalClient(self.server,validate)
    def records(self):
        request=self.server.accept_request(self.data['query'])
        evidence=self.client.acquire_evidence(request)
        return request,evidence,self.client.calculate_ranking(evidence)
    def test_generated_client_matches_authoritative_contract(self):
        p=Path(__file__).parents[1]/'contracts/api-v1.yaml'
        self.assertEqual(CONTRACT_SHA256,hashlib.sha256(p.read_bytes()).hexdigest())
        self.assertEqual({x['id'] for x in SPEC['x-model-flows']},{'IF.01','IF.02','IF.03','IF.04'})
        self.assertEqual(next(x for x in SPEC['x-model-flows'] if x['id']=='IF.03')['destination'],['F.4','F.5'])
    def test_five_functions_execute_once_and_keep_independent_oracle(self):
        result=self.server.compare(self.data['query'])
        self.assertEqual(self.server.trace,['F.1','F.2','F.3','F.4','F.5'])
        oracle=independent_scores(self.data['market'],self.data['query']['stock_pair'])
        for r in result['comparison_and_evidence']['scores']:self.assertAlmostEqual(r['score'],oracle[r['symbol']]['score'],delta=1e-6)
    def test_extra_fields_cannot_cross_boundary(self):
        request=self.server.accept_request(self.data['query']);request['api_key']='rejected-test-marker'
        with self.assertRaises(ContractError):self.client.acquire_evidence(request)
        self.assertEqual(self.server.trace,['F.1'])
    def test_return_schema_is_enforced_not_only_request(self):
        self.server.acquire_evidence=lambda _: {'unexpected':'not evidence'}
        with self.assertRaises(ContractError):self.client.acquire_evidence(self.server.accept_request(self.data['query']))
    def test_changed_control_version_is_rejected(self):
        request=self.server.accept_request(self.data['query']);request['configuration_version']='different'
        with self.assertRaises(ContractError):self.client.acquire_evidence(request)
    def test_join_rejects_unrelated_explanation(self):
        _,_,computed=self.records();checked=self.client.check_explanation(deepcopy(computed));checked['comparison_id']='different'
        with self.assertRaises(ContractError):self.client.present_comparison({'computed':computed,'checked':checked})
    def test_external_ai_cannot_mutate_authoritative_fanout(self):
        def hostile(p):p['scores'][0]['score']=999;return controlled_ai(p)
        self.server.ai=hostile
        out=self.server.compare(self.data['query']);self.assertIsNone(out['comparison_and_evidence']['explanation'])
        oracle=independent_scores(self.data['market'],self.data['query']['stock_pair'])
        self.assertAlmostEqual(out['comparison_and_evidence']['scores'][0]['score'],oracle['AAPL']['score'])
    def test_no_undocumented_public_routes(self):
        from walking_skeleton.backend.main import app
        actual={(m,r.path) for r in app.routes for m in getattr(r,'methods',[]) if m not in {'HEAD','OPTIONS'}}
        self.assertEqual(actual,{('GET','/'),('POST','/compare'),('GET','/research'),('POST','/research/compare'),('GET','/research/status'),('POST','/research/configuration'),('GET','/research/evidence/{source_id}')})
