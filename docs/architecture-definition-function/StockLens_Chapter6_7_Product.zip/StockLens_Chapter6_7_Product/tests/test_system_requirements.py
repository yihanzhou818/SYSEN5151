"""Model-derived native requirement cases. Controlled verification, not real-service acceptance.
The reference arithmetic is independent Decimal/direct counting, not a call to engine helpers.
"""
from copy import deepcopy
from decimal import Decimal,localcontext
import importlib,inspect,json,math
from pathlib import Path
import unittest
from functional_architecture.contracts import CONFIG,ContractError,ConfigurationStore,ServiceUnavailable
from functional_architecture.runtime import ResearchRuntime
from functional_architecture.provide_stock_comparisons import provide_stock_comparisons,queries
from functional_architecture.supply_dated_market_records import supply_dated_market_records
from functional_architecture.supply_dated_news_evidence import supply_dated_news_evidence
from functional_architecture.generate_grounded_explanation_text import generate_grounded_explanation_text,canonical_text
from functional_architecture.request_and_review_stock_research import request_and_review_stock_research
from functional_architecture.configure_and_monitor_research_service import configure_and_monitor_research_service

FIXTURE=Path(__file__).parent/'fixtures/ch4_ch5/synthetic_snapshot.json'

def controlled_ai(payload):
    return {'comparison_id':payload['comparison_id'],'text':canonical_text(payload),
            'source_ids':[s['id'] for s in payload['sources']],'mode':'synthetic-verification'}

def independent_scores(market,pair):
    with localcontext() as context:
        context.prec=40;momentum={};volatility={}
        for symbol,raw in market['prices'].items():
            p=[Decimal(str(v)) for v in raw];r=[p[i]/p[i-1]-1 for i in range(1,21)]
            mean=sum(r)/20
            momentum[symbol]=p[20]/p[0]-1
            volatility[symbol]=(sum((v-mean)**2 for v in r)/19).sqrt()
        expected={}
        for symbol in pair:
            parts=[]
            for values,reverse in [(momentum,False),(volatility,True)]:
                less=sum(v<values[symbol] for v in values.values())
                equal=sum(v==values[symbol] for v in values.values())
                rank=Decimal(1+less)+Decimal(equal-1)/2
                parts.append(100*((10-rank) if reverse else (rank-1))/9)
            expected[symbol]={'momentum':float(momentum[symbol]),'volatility':float(volatility[symbol]),'score':float(sum(parts)/2)}
        return expected

class SystemRequirementTests(unittest.TestCase):
    def setUp(self):
        self.data=json.loads(FIXTURE.read_text());self.query=self.data['query'];self.config=deepcopy(CONFIG)
        self.runtime=ResearchRuntime(lambda _:deepcopy(self.data['market']),lambda _:deepcopy(self.data['news']),controlled_ai)

    def test_REQ_1_1_1_V111_accept_pair_and_date(self):
        view=self.runtime.compare(self.query)['comparison_and_evidence']
        self.assertEqual(view['requested_query'],self.query)
        for bad in [['AAPL','AAPL'],['UNKNOWN','MSFT'],['AAPL']]:
            with self.subTest(pair=bad),self.assertRaises(ContractError):self.runtime.compare({**self.query,'stock_pair':bad})
        with self.assertRaises(ContractError):self.runtime.compare({**self.query,'analysis_date':'not-a-date'})

    def test_REQ_1_1_2_V112_dated_market_coverage(self):
        mq,_=queries(self.query,self.config)
        result=supply_dated_market_records(market_query=mq,mechanism=lambda _:self.data['market'])
        self.assertEqual(result['trading_dates'][-1],self.query['analysis_date'])
        broken=deepcopy(result);broken['prices']['XOM']=broken['prices']['XOM'][:-1]
        with self.assertRaises(ContractError):supply_dated_market_records(market_query=mq,mechanism=lambda _:broken)

    def test_REQ_1_1_3_V113_news_source_support(self):
        _,nq=queries(self.query,self.config);news=supply_dated_news_evidence(news_query=nq,mechanism=lambda _:self.data['news'])
        self.assertEqual(len(news),2)
        for item in news:self.assertIn(item['excerpt'],item['supporting_text']);self.assertTrue(item['published_at'])
        bad=deepcopy(news);bad[0]['supporting_text']='unrelated'
        with self.assertRaises(ContractError):supply_dated_news_evidence(news_query=nq,mechanism=lambda _:bad)

    def test_REQ_1_1_4_V114_checked_explanation(self):
        result=self.runtime.compare(self.query);package=result['score_evidence_package'];before=deepcopy(package)
        response=generate_grounded_explanation_text(score_evidence_package=package,mechanism=controlled_ai)
        self.assertEqual(response['source_ids'],[x['id'] for x in package['sources']]);self.assertEqual(package,before)
        bad=controlled_ai(package);bad['text']='AAPL score=999'
        with self.assertRaises(ContractError):generate_grounded_explanation_text(score_evidence_package=package,mechanism=lambda _:bad)

    def test_REQ_1_1_5_V115_configuration_atomic(self):
        before=deepcopy(self.runtime.store.configuration);bad={**before,'window':0}
        with self.assertRaises(ContractError):self.runtime.configure(bad)
        self.assertEqual(before,self.runtime.store.configuration)
        self.runtime.configure({**before,'version':'reviewed-test-version'})
        self.assertEqual(self.runtime.compare(self.query)['service_status']['configuration_version'],'reviewed-test-version')

    def test_REQ_1_2_1_V121_result_independent_oracle(self):
        view=self.runtime.compare(self.query)['comparison_and_evidence'];expected=independent_scores(self.data['market'],self.query['stock_pair'])
        for row in view['scores']:
            for field in ('score','momentum','volatility'):self.assertAlmostEqual(row[field],expected[row['symbol']][field],delta=1e-10)
        self.assertEqual(view['observation_date'],self.query['analysis_date']);self.assertTrue(view['sources']);self.assertTrue(view['explanation'])

    def test_REQ_1_2_2_V122_market_query(self):
        observed=[];original=self.runtime.market
        self.runtime.market=lambda query:(observed.append(deepcopy(query)) or original(query))
        result=self.runtime.compare(self.query)
        self.assertEqual(observed,[result['market_query']]);self.assertEqual(observed[0]['stock_pair'],self.query['stock_pair'])
        self.assertEqual(observed[0]['window'],20);self.assertEqual(len(observed[0]['universe']),10)

    def test_REQ_1_2_3_V123_news_query(self):
        observed=[];original=self.runtime.news
        self.runtime.news=lambda query:(observed.append(deepcopy(query)) or original(query))
        result=self.runtime.compare(self.query)
        self.assertEqual(observed,[result['news_query']]);self.assertEqual(observed[0]['days'],7);self.assertEqual(observed[0]['limit_per_stock'],2)

    def test_REQ_1_2_4_V124_evidence_package_no_credentials(self):
        captured=[]
        self.runtime.ai=lambda p:(captured.append(deepcopy(p)) or controlled_ai(p))
        result=self.runtime.compare(self.query);self.assertEqual(captured,[result['score_evidence_package']])
        self.assertEqual(set(captured[0]),{'comparison_id','analysis_date','cutoff_at','configuration_version','scores','sources'})
        self.assertNotIn('password',json.dumps(captured));self.assertNotIn('api_key',json.dumps(captured))

    def test_REQ_1_2_5_V125_status_outcomes(self):
        self.assertEqual(self.runtime.store.service_status['state'],'ready')
        self.assertEqual(self.runtime.compare(self.query)['service_status']['state'],'completed')
        self.runtime.ai=None
        self.assertEqual(self.runtime.compare(self.query)['service_status']['state'],'completed_with_limitations')
        with self.assertRaises(ContractError):self.runtime.compare({**self.query,'stock_pair':['X','Y']})
        self.assertEqual(self.runtime.store.service_status['state'],'failed')

    def test_REQ_1_3_1_V131_user_request_result_association(self):
        result=self.runtime.compare(self.query)['comparison_and_evidence']
        exchange=request_and_review_stock_research(self.query,result,research_configuration=self.config,mechanism='automated caller')
        self.assertEqual(exchange['stock_pair_date'],result['requested_query']);self.assertEqual(result['mode'],'synthetic-verification')
        with self.assertRaises(ContractError):request_and_review_stock_research({**self.query,'stock_pair':['AMZN','META']},result,research_configuration=self.config,mechanism='automated caller')

    def test_REQ_1_3_2_V132_market_interface_roundtrip(self):
        result=self.runtime.compare(self.query)
        self.assertEqual(result['market_query']['analysis_date'],result['comparison_and_evidence']['observation_date'])
        bad=deepcopy(self.data['market']);bad['trading_dates'][-1]='2099-01-01';self.runtime.market=lambda _:bad
        with self.assertRaises(ContractError):self.runtime.compare(self.query)

    def test_REQ_1_3_3_V133_news_interface_dates(self):
        late=deepcopy(self.data['news'][0]);late['id']='FUTURE';late['published_at']='2099-01-01T00:00:00+00:00'
        self.runtime.news=lambda _:self.data['news']+[late]
        ids=[x['id'] for x in self.runtime.compare(self.query)['comparison_and_evidence']['sources']]
        self.assertNotIn('FUTURE',ids)

    def test_REQ_1_3_4_V134_ai_interface_fail_closed(self):
        def wrong(p):
            response=controlled_ai(p);response['comparison_id']='another-comparison';return response
        self.runtime.ai=wrong;result=self.runtime.compare(self.query)
        self.assertIsNone(result['comparison_and_evidence']['explanation']);self.assertEqual(self.runtime.ai_calls,2)
        expected=independent_scores(self.data['market'],self.query['stock_pair'])
        for row in result['comparison_and_evidence']['scores']:self.assertAlmostEqual(row['score'],expected[row['symbol']]['score'])

    def test_REQ_1_3_5_V135_automated_maintenance_cycle(self):
        cfg=deepcopy(self.config);cfg['version']='handover-test-configuration'
        status=self.runtime.configure(cfg)
        out=configure_and_monitor_research_service(status,research_configuration=cfg,mechanism='automated operator, not independent human')
        self.assertEqual(out,cfg);self.assertEqual(self.runtime.compare(self.query)['service_status']['configuration_version'],cfg['version'])

    def test_REQ_1_4_1_V141_end_to_end_icom(self):
        result=self.runtime.compare(self.query)
        self.assertEqual(set(result),{'comparison_and_evidence','market_query','news_query','score_evidence_package','service_status'})
        view=result['comparison_and_evidence'];oracle=independent_scores(self.data['market'],self.query['stock_pair'])
        for row in view['scores']:self.assertAlmostEqual(row['score'],oracle[row['symbol']]['score'],delta=1e-6)
        self.assertEqual(view['explanation']['text'],canonical_text(result['score_evidence_package']))
        self.assertTrue(all(s['excerpt'] in s['supporting_text'] for s in view['sources']))
        self.assertTrue(all(s['published_at']<=self.query['cutoff_at'] for s in view['sources']))

    def test_equal_factors_rank_ties_are_fifty(self):
        market=deepcopy(self.data['market']);market['prices']={s:[100.0]*21 for s in CONFIG['universe']}
        self.runtime.market=lambda _:market;view=self.runtime.compare(self.query)['comparison_and_evidence']
        self.assertTrue(view['tied']);self.assertTrue(all(r['score']==50 for r in view['scores']))

    def test_nonfinite_and_missing_universe_rejected(self):
        for value in [float('nan'),float('inf'),0,-1,True]:
            bad=deepcopy(self.data['market']);bad['prices']['AAPL'][0]=value;self.runtime.market=lambda _:bad
            with self.subTest(value=value),self.assertRaises(ContractError):self.runtime.compare(self.query)
        bad=deepcopy(self.data['market']);del bad['prices']['XOM'];self.runtime.market=lambda _:bad
        with self.assertRaises(ContractError):self.runtime.compare(self.query)

    def test_missing_news_and_unselected_ai_are_explicit(self):
        self.runtime.news=lambda _:[];self.runtime.ai=None
        out=self.runtime.compare(self.query)
        self.assertEqual(out['comparison_and_evidence']['sources'],[]);self.assertIsNone(out['comparison_and_evidence']['explanation'])
        self.assertEqual(out['service_status']['state'],'completed_with_limitations');self.assertEqual(self.runtime.ai_calls,0)

    def test_icom_controls_and_mechanisms_keyword_only(self):
        signature=inspect.signature(provide_stock_comparisons)
        for key in ('research_configuration','mechanism'):self.assertEqual(signature.parameters[key].kind,inspect.Parameter.KEYWORD_ONLY)
        records=json.loads((Path(__file__).parents[1]/'model-artifacts/ch4-ch5/function-module-map.json').read_text())
        self.assertEqual(len(records),6)
        for record in records:
            module=importlib.import_module(record['module']);self.assertIn(str(record['entity']),module.__doc__)

    def test_provider_outage_has_failed_state(self):
        def unavailable(_):raise ServiceUnavailable('controlled outage')
        self.runtime.market=unavailable
        with self.assertRaises(ServiceUnavailable):self.runtime.compare(self.query)
        self.assertEqual(self.runtime.store.service_status['state'],'failed')

    def test_ai_timeout_retries_once_then_limits_result(self):
        def timeout(_):raise TimeoutError('controlled timeout')
        self.runtime.ai=timeout
        result=self.runtime.compare(self.query)
        self.assertEqual(self.runtime.ai_calls,2)
        self.assertEqual(result['service_status']['state'],'completed_with_limitations')
