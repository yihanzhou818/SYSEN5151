"""Local transport for the Chapter 2 walking skeleton; no real services."""
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel

from walking_skeleton import dashboard_ui
app = FastAPI(title="StockLens Controlled Research", docs_url=None, redoc_url=None, openapi_url=None)


class ComparisonQuery(BaseModel):
    stock_a: str
    stock_b: str
    analysis_date: str


@app.get("/")
def dashboard():
    return FileResponse(Path(__file__).resolve().parents[1] / "frontend" / "index.html")


@app.post("/compare")
def compare(query: ComparisonQuery):
    result = dashboard_ui.transmit_evaluation_request(
        query.stock_a, query.stock_b, query.analysis_date
    )
    return dashboard_ui.render_comparison_dashboard(result)

# Chapter 4–5 is a separately labelled controlled verification path.
# The existing /compare fixture remains unchanged for earlier evidence/tests.
from functional_architecture.verification_fixture import verification_runtime,fixture_data
from functional_architecture.contracts import ContractError,ServiceUnavailable
from fastapi import HTTPException
research_runtime=verification_runtime()

class ResearchQuery(BaseModel):
    stock_a:str
    stock_b:str
    analysis_date:str
    cutoff_at:str

@app.get('/research')
def research_dashboard():
    return FileResponse(Path(__file__).resolve().parents[1]/'frontend'/'research.html')

@app.post('/research/compare')
def research_compare(query:ResearchQuery):
    try:
        return research_runtime.compare({'stock_pair':[query.stock_a,query.stock_b],
            'analysis_date':query.analysis_date,'cutoff_at':query.cutoff_at})
    except ContractError as error:
        raise HTTPException(status_code=400,detail=str(error)) from error
    except (ServiceUnavailable,TimeoutError) as error:
        raise HTTPException(status_code=503,detail=str(error)) from error

@app.get('/research/status')
def research_status():
    return {'service_status':research_runtime.store.service_status,
            'configuration':research_runtime.store.configuration,
            'verification_query':fixture_data()['query'],
            'notice':'Synthetic local verification; no real provider or AI call.'}

@app.post('/research/configuration')
def research_configuration(configuration:dict):
    try:return research_runtime.configure(configuration)
    except ContractError as error:raise HTTPException(status_code=400,detail=str(error)) from error

@app.get('/research/evidence/{source_id}')
def research_evidence(source_id:str):
    for item in fixture_data()['news']:
        if item['id']==source_id:return item
    raise HTTPException(status_code=404,detail='Unknown synthetic verification source')
