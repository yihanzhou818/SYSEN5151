"""Read-only structural audit of exported Innoslate UI records (not runtime tests)."""
import json
from pathlib import Path
base = Path(__file__).resolve().parent
records = json.loads((base / 'functions-verified.json').read_text())
by_id = {r['url'].rsplit('/', 1)[-1]: r for r in records}
def links(r, kind):
    return {e['href'].rsplit('/', 1)[-1] for rel in r['relations'] if rel['type'] == kind for e in rel['entities']}
checks = []
def check(name, ok):
    checks.append({'check': name, 'passed': bool(ok)})
root = by_id['264782']
first = [by_id[i] for i in sorted(links(root, 'decomposed by'))]
check('five_first_level_functions', len(first) == 5)
requirements = set()
for parent in first:
    children = [by_id[i] for i in links(parent, 'decomposed by')]
    n = parent['number']
    check(n + '_two_children', len(children) == 2)
    for relation in ['receives', 'generates']:
        carried = set().union(*(links(c, relation) for c in children))
        check(n + '_' + relation + '_no_tunnels', links(parent, relation) <= carried)
    check(n + '_no_mechanism_allocation', not links(parent, 'performed by'))
    requirements |= links(parent, 'satisfies')
check('16_system_requirements_allocated', len(requirements) == 16 and requirements == links(root, 'satisfies'))
result = {'checks': checks, 'passed': all(x['passed'] for x in checks)}
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['passed'] else 1)
